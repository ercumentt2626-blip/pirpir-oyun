Pırpır Oyun V51 - Netlify statik dağıtım.
V50 temel alınmıştır. Seçilen karakter görseli korunarak kesit tabanlı bacak hareketi, bekleme nefesi ve kılıç savurma görsel animasyonu eklendi.
Not: Bu animasyonlar ayrı karelerden üretilmiş sprite sheet değil, mevcut görselden oluşturulan parçalı animasyonlardır.
index.html ana sayfadır.
